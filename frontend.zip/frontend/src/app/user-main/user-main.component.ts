import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/Http';

@Component({
  selector: 'app-user-main',
  templateUrl: './user-main.component.html',
  styleUrls: ['./user-main.component.css']
})
export class UserMainComponent implements OnInit {
  resp;
  constructor(private http: HttpClient) { }

  ngOnInit() {
    let usrId = localStorage.getItem('id');
    this.http.post('http://localhost:3000/getUser', ({ _id: usrId })).subscribe((data) => {
      this.resp = data[0];
    })
  }

}

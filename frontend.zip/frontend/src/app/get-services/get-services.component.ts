import { HttpClient } from '@angular/common/Http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-get-services',
  templateUrl: './get-services.component.html',
  styleUrls: ['./get-services.component.css']
})
export class GetServicesComponent implements OnInit {

  constructor(private route: ActivatedRoute, private http: HttpClient) { }
  id;
  services;
  hospitals;
  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.id = params.params.id;
      this.http.post('http://localhost:3000/getServices', { _id: this.id }).subscribe((data) => {
        console.log(data.specialization)
        this.services = data.specialization;
      })
    })
    this.http.get('http://localhost:3000/getAdmin?_id=' + this.id).subscribe(res => {
      console.log(res)
      localStorage.setItem('hosId', res[0]._id)
      
      this.hospitals = res[0];
    })
  }

}

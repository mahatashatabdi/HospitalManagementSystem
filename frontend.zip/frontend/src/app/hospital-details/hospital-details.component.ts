import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-hospital-details',
  templateUrl: './hospital-details.component.html',
  styleUrls: ['./hospital-details.component.css']
})
export class HospitalDetailsComponent implements OnInit {
  doctors;
  hosId;
  constructor(private http: Http) { }

  ngOnInit() {
    let id = localStorage.getItem('id');
    this.hosId = id;
    this.http.get('http://localhost:3000/getDocDetails?hosId=' + id).subscribe((data) => {
      console.log(data)
      let resp = data.json()
      console.log(resp)
      this.doctors = (resp);
    })
  }
  delDoc(data) {
    this.http.post('http://localhost:3000/delDoc', { hosId: this.hosId, docId: data }).subscribe((data)=>{
      console.log(data)
    })
  }
}

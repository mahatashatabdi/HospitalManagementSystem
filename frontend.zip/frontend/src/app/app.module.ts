import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CalendarModule } from 'angular-calendar';
import { MatAutocompleteModule, MatInputModule, MatCardModule, MatDividerModule, MatListModule, MatToolbarModule } from '@angular/material';




import { AppComponent } from './app.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { MainSideNavComponent } from './main-side-nav/main-side-nav.component';
import { MainPageComponent } from './main-page/main-page.component';
import { MainServicesComponent } from './main-services/main-services.component';
import { LoginComponent } from './login/login.component';
import { ErrorComponent } from './error/error.component';
import { SignupComponent } from './signup/signup.component';
import { UserMainComponent } from './user-main/user-main.component';
import { AdminSignUpComponent } from './admin-sign-up/admin-sign-up.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddSpecializationComponent } from './add-specialization/add-specialization.component';
import { HospitalDetailsComponent } from './hospital-details/hospital-details.component';
import { UserNavComponent } from './user-nav/user-nav.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { AddDoctorComponent } from './add-doctor/add-doctor.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { GetServicesComponent } from './get-services/get-services.component';
import { GetDoctorComponent } from './get-doctor/get-doctor.component';
import { MainComponent } from './main/main.component';
import { UserComponent } from './user/user.component';
import { UserLogoutComponent } from './user-logout/user-logout.component';
import { AdminComponent } from './admin/admin.component';
import { AppointmentsComponent } from './appointments/appointments.component';

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    MainSideNavComponent,
    MainPageComponent,
    MainServicesComponent,
    LoginComponent,
    ErrorComponent,
    SignupComponent,
    UserMainComponent,
    AdminSignUpComponent,
    AdminLoginComponent,
    AdminHomeComponent,
    AddSpecializationComponent,
    HospitalDetailsComponent,
    UserNavComponent,
    AdminNavComponent,
    AddDoctorComponent,
    UserSearchComponent,
    GetServicesComponent,
    GetDoctorComponent,
    MainComponent,
    UserComponent,
    UserLogoutComponent,
    AdminComponent,
    AppointmentsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CalendarModule,
    HttpModule,
    MatCardModule,
    MatToolbarModule,
    MatInputModule,
    MatAutocompleteModule,
    BrowserAnimationsModule,
    MatDividerModule,
    MatListModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {
        path: '',
        component: MainComponent,
        children: [
          {
            path: '',
            component: MainPageComponent
          },
          {
            path: 'services',
            component: MainServicesComponent
          },
          {
            path: 'login',
            component: LoginComponent
          },
          {
            path: 'login/signup',
            component: SignupComponent
          },
          {
            path: 'login/adminLogin',
            component: AdminLoginComponent
          },
          {
            path: "adminSignUp",
            component: AdminSignUpComponent
          },
        ]
      }, {
        path: 'user',
        component: UserComponent,
        children: [
          {
            path: '',
            component: UserMainComponent
          }, {
            path: 'searchHospital',
            component: UserSearchComponent,
          }, {
            path: 'searchHospital/getServices/:id',
            component: GetServicesComponent
          }, {
            path: 'logout',
            component: UserLogoutComponent
          }
        ]
      }, {
        path: 'getDoctor/:id',
        component: GetDoctorComponent
      }, {
        path: 'admin',
        component: AdminComponent,
        children: [{
          path: '',
          component: HospitalDetailsComponent
        },
        {
          path: 'addSpecialization', component: AddSpecializationComponent
        },
        {
          path: 'addDoctor', component: AddDoctorComponent
        },
        {
          path:'appointments',component:AppointmentsComponent
        },
        {
          path: 'logout', component: UserComponent
        }
        ]
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

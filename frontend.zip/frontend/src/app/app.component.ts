import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  role = false;
  admin = false;
  user = false;
  constructor() { }
  ngOnInit() {

    console.log(localStorage.getItem('role'))
    if (localStorage.getItem('role') === "user") {
      console.log("user")
      this.user = true;
      this.role = false;

    }
    else if (localStorage.getItem('role') === "admin") {
      console.log("admin")
      this.admin = true;
    }
    else {
      console.log("null")
      this.role = true;
      this.user = false;
    }
  }

}

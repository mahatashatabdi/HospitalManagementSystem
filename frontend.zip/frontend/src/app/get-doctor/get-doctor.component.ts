import { HttpClient } from '@angular/common/Http';
import { Http } from '@angular/Http';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-doctor',
  templateUrl: './get-doctor.component.html',
  styleUrls: ['./get-doctor.component.css']
})
export class GetDoctorComponent implements OnInit {
  serId;
  result;
  hosId;
  usrId;
  doctors;
  showForm = true;
  timings = ['09:00 am - 10:00 am', '10:00 am - 11:00 am', '11:00 am - 12:00 pm', '12:00 pm - 01:00 pm', '01:00 pm - 02:00 pm', '02:00 pm - 03:00 pm', '03:00 pm - 04:00 pm', '04:00 pm - 5:00 pm', '05:00 pm - 06:00 pm', '06:00 pm - 07:00 pm', '07:00 pm - 08:00 pm', '08:00 pm - 09:00 pm'];
  docTimings;
  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      console.log(params.params.id);
      this.serId = params.params.id;
      this.usrId = localStorage.getItem('id')
      this.hosId = localStorage.getItem('hosId');
      this.http.post('http://localhost:3000/getDoctor', { spId: this.serId, hosId: this.hosId }).subscribe(data => {
        console.log(data);
        this.doctors = data[0];
        this.http.get('http://localhost:3000/getAppointments?_id=' + this.doctors.docId).subscribe((appointments) => {
          let appJson = JSON.stringify(appointments)
          // const a = new Set(['1', '2', '3']);
          // const b = new Set(['4', '3', '2']);
          // console.log(new Set(
          //     [...a].filter(x => !b.has(x))));
          let a = new Set(this.timings)
          let b = new Set(appJson)
          this.docTimings = this.timings.filter(item => appJson.indexOf(item) < 0);
        })
      });

    })

  }

  takeAppointment(value) {
    console.log(value.time)
    this.http.post('http://localhost:3000/bookDoc', {
      _id: this.doctors.docId,
      hosId: this.hosId,
      appointment: value.time,
      patId: this.usrId
    }).subscribe(data => {
      console.log(data)
      if (data.status = "ok") {
        this.showForm = false;
        this.result = {
          value: "Your Appointment was successful with Dr. " + this.doctors.docName + ' at ' + value.time + ' today!',
          class: "alert alert-success"
        }
      }
      else {
        this.result = {
          value: "Your Appointment with Dr. " + this.doctors.docName + "was failed",
          class: "alert alert-danger"
        }
      }
    })
  }
}  

import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';



@Component({
  selector: 'app-admin-sign-up',
  templateUrl: './admin-sign-up.component.html',
  styleUrls: ['./admin-sign-up.component.css']
})
export class AdminSignUpComponent implements OnInit {

  hospitalName: string = '';
  _id: string = '';
  hospitalPassword: string = '';
  hospitalNumber: string = '';
  hospitalCity: string = '';
  hospitalAddress: string = '';
  constructor(private http: Http, private router: Router) { }
  SelectedFile: File = null;
  ngOnInit() {
  }
  onFileSelected(event) {
    this.SelectedFile = <File>event.target.files[0];
    console.log(this.SelectedFile)
    console.log(this.hospitalName)
  }

  // _id: String,
  // hospitalName: String,
  // hospitalPassword: String,
  // hospitalNumber: ,
  // hospitalCity: String,
  // hospitalAddress: String,
  // path:String

  adminSignUp() {

    const fd = new FormData();

    fd.append('_id', this._id)
    fd.append('hospitalName', this.hospitalName)
    fd.append('hospitalPassword', this.hospitalPassword)
    fd.append('hospitalNumber', this.hospitalNumber)
    fd.append('hospitalCity', this.hospitalCity)
    fd.append('hospitalAddress', this.hospitalAddress)
    fd.append('photo', this.SelectedFile, this.SelectedFile.name);
    console.log(fd)
    this.http.post('http://localhost:3000/adminSignUp', fd).subscribe((resp) => {
      console.log(resp)
      this.router.navigateByUrl('login/adminLogin')
    })
  }

}

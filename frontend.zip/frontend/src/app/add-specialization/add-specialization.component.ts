import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/Http';

@Component({
  selector: 'app-add-specialization',
  templateUrl: './add-specialization.component.html',
  styleUrls: ['./add-specialization.component.css']
})

export class AddSpecializationComponent {

  constructor(private http: HttpClient) { }
  specializations = ['Allergology', 'Cardiology', 'Dental', 'Dermatology', 'Gastroenterology', 'Gynecology', 'Neurosurgery', 'Ophthalmology', 'Orthopedic', 'Radiology', 'Urology']
  result;

  add(data) {

    let id = localStorage.getItem('id');
    console.log(id);
    this.http.post('http://localhost:3000/addService', { id: id, spl: data.special }).subscribe((resp) => {

      if (resp.status == "ok") {
        this.result = {
          value: "You have inserted " + data.special + " to your services!",
          class: "alert alert-success"
        }
      }
      else {
        this.result = {
          value: "There is a problem adding " + data.special + " to your services!",
          class: "alert alert-danger"
        }
      }
    })
  }
}

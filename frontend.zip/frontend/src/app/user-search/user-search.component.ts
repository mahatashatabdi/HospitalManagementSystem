import { Http } from '@angular/Http';
import { HttpClient } from '@angular/common/Http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css']
})
export class UserSearchComponent implements OnInit {

  constructor(private http: HttpClient) { }
  cities;
  hospitals;
  ngOnInit() {
    this.http.get('http://localhost:3000/getCity').subscribe((cities) => {
      console.log(cities)
      this.cities = cities;
    })
  }

  find(data) {
    let location = data.location;
    this.http.post('http://localhost:3000/findHospitals', { hospitalCity: location }).subscribe((data) => {
      console.log(data)
      this.hospitals = (data);
    })
  }
}

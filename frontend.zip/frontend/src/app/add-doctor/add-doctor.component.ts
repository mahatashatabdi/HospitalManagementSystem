import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router'

@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.css']
})
export class AddDoctorComponent implements OnInit {
  spl;
  hosI;
  constructor(private http: Http, private router: Router) { }

  ngOnInit() {
    let id = localStorage.getItem('id');
    this.hosI = id;
    if (!id) {
      this.router.navigateByUrl('/adminLogin')
    }
    this.http.post('http://localhost:3000/getServices', { _id: id }).subscribe((data) => {
      console.log(data)
      let resp = data.json();
      this.spl = resp.specialization;
      console.log(this.spl)
    })
  }
  result;
  addDoctor(data) {
    data["hosId"] = this.hosI
    this.http.post('http://localhost:3000/addDoctor', data).subscribe((result) => {
      let res = result.json()
      if (res.status == "ok") {
        this.result = {
          message: "Dr. " + res.name + " Added successfully!",
          class: "alert alert-success"
        }
      }
      else {
        this.result = {
          message: "Unable to add Dr. " + res.name + " as doctor!",
          class: "alert alert-danger"
        }
      }
    })
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  constructor(private http: Http, private router: Router) {

  }

  ngOnInit() {
  }

  login(data) {
    this.http.post('http://localhost:3000/adminLogin', data).subscribe((resp) => {
      var res = resp.json();
      console.log(res)
      if (res.status == "ok") {
        console.log(res.id)
        localStorage.setItem('id', res.id)
        localStorage.setItem('role', 'admin')
        this.router.navigateByUrl('/admin')
      }
    })
  }
}

import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})



export class SignupComponent implements OnInit {

  constructor(private http: Http, private router: Router) { }

  ngOnInit() {
  }
  signup(data) {
    this.http.post('http://localhost:3000/signUp', data).subscribe(resp => {
      var res = resp.json()
      if (res.status == "ok") {
        this.router.navigateByUrl('/login')
      }
      else {
        alert("something went wrong, please try again")
      }
    })
  }

}

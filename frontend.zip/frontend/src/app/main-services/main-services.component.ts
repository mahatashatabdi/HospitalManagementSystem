import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-services',
  templateUrl: './main-services.component.html',
  styleUrls: ['./main-services.component.css']
})
export class MainServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

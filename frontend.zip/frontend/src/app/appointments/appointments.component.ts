import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  doctors;
  hosId;
  appointments;
  constructor(private http: Http) { }

  ngOnInit() {
    let id = localStorage.getItem('id');
    console.log(id)
    this.hosId = id;
    this.http.get('http://localhost:3000/getDocDetails?hosId=' + id).subscribe((data) => {
      console.log(data.json())
      this.doctors = data.json();
    })
  }
  searchAppointments(data) {
    alert(JSON.stringify(data))
    this.http.get('http://localhost:3000/appointments?hosId=' + this.hosId + "&docId=" + data.docId).subscribe((data) => {
      console.log(data.json())

      data = data.json();
      this.appointments = data[0].appointments
    })
  }

}

import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
  logs
  constructor(private http: Http, private router: Router) { }
  ngOnInit() {
  }
  log(data) {
    console.log(data)
    alert(JSON.stringify(data))
    this.logs = JSON.stringify(data);

  }
  login(data) {
    return this.http.post("http://localhost:3000/login", { 'mail': data.userName, 'password': data.userPwd }).subscribe(resp => {
      var a = resp.json()
      console.log(a.email);
      if (a.status == "ok") {
        console.log(a.email)
        localStorage.setItem('id', a.email);
        this.router.navigateByUrl('/user');
      }
    })
  }
}